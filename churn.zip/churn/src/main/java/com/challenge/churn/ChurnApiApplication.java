package com.challenge.churn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChurnApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChurnApiApplication.class, args);
	}

}
